package day14;


class vehicle {
	void method() {
		System.out.println("vehicle engine started..");
	}
}

class car extends vehicle {
	void display() {
		System.out.println("car is driving");
	}
}

class electriccar  extends car{
	void display() {
		System.out.println("bike is kickstarted...");
	}
}



class bike extends vehicle {
	void kickstart() {
		System.out.println("electric car is charing...");
	}
}



public class inheritancetask {
	public static void main(String[] args) {
		
		
		//single Inheritance
		car c = new car();
		c.display();
		c.method();
		
		
		//mutiLevel Inheritance
		electriccar ec = new electriccar();
		ec.display();
		ec.method();
		
		
		//hier
		bike bb=new bike();
		bb.kickstart();
		bb.method();
		
	}}

		

