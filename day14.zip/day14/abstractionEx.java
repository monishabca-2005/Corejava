package day14;
abstract class calculator {
	abstract void add(int a,int b);
	abstract void sub(int a,int b);
	
	public void mul() {
		System.out.println("multiplication "+(2*7));
	}
	
}

public class abstractionEx extends calculator {
	 
	public void add(int a,int b) {
		System.out.println("addition "+(a+b));
	}
	public void sub(int a,int b) {
		System.out.println("subraction "+(a-b));
	}
	
		public static void main(String[] args) {
			abstractionEx abs =new abstractionEx();
			abs.add(100, 20);
			abs.sub(30, 20);
			abs.mul();
		}
	}
	


