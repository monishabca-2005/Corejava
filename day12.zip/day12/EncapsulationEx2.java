package day12;

public class EncapsulationEx2 {
	public static void main(String[] args) {
		Book bk1 = new Book();
		bk1.setId(1001);
		System.out.println(bk1.getId());
		bk1.setName("Harry potter");
		System.out.println(bk1.getbookName());
        bk1.setauthorname("Muthesh");
        System.out.println(bk1.getauthorname());
        bk1.setprice(1200);
        System.out.println(bk1.getprice());
	}
}

class Book {
	private int id;
	private String bookname;
	private String authorname;
	private long price;

	public int getId() {
		return id;
	}

	public void setId(int bk1Id) {
		id = bk1Id;

	}

	public String getbookName() {
		return bookname;
		
	}

	public void setName(String bk1Name) {
		bookname=bk1Name;
	}
	public String getauthorname() {
		return authorname;
		
	}
	public void setauthorname(String bk1author) {
		authorname =bk1author;
		
	}
	public long getprice() {
		return price;
		
	}
	public void setprice(long bk1price) {
		price =bk1price;
		
	}
	
	}
