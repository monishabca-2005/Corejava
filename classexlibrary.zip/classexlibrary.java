package day9;



 class info{
int id;
String bookname;
String authorname;
double price;
}
 public class classexlibrary
 {
	public static void main(String[]args)
	{
		info book1=new info();
		book1.id=8754667;
		book1.bookname="harry potter";
		book1.authorname="vignesh";
		book1.price=500;
		
		System.out.println("id "+book1.id + "\nbookname " + book1.bookname + "\nauthorname " + book1.authorname + "\nprice " + book1.price);
}

}
