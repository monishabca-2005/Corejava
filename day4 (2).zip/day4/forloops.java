package day4;

public class forloops {
public static void main(String[]args) {
	for(int i=1;i<=5;)
	{
		System.out.println("good girl");
	}
}
}
