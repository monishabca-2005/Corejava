package day16;


class animal{
 void display() {
	 System.out.println("this is animal");
 }
}
class dog extends animal{
	void display() {
		System.out.println("dog is my fav");
	}
}
class jaya extends animal{
	void moni() {
		System.out.println("jaya is a donkey");
	}
	
}

public class InheritnceEx {
	public static void main(String[]args) {
		jaya jay =new jaya();
		jay.moni();
		jay.display();
	}

}
