package day10;

public class student{
	int id;
	String name;
	long phoneno;
	double salary;
 public void display() {
	 System.out.println("id: "+id);
	 System.out.println("name: "+name);
	 System.out.println("phoneno: "+phoneno);
	 System.out.println("salary: "+salary);
 }
	
	public static void main(String[]args)
	{
		student std1 =new student();
		std1.id=1;
		std1.name="meha";
		std1.phoneno=962922288;
		std1.salary=2000.8;
		std1.display();
				

		
		
	}

}