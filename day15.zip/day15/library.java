package day15;

public class library {
private int id;
private String bookname;
private String authorname;
private double price;

library(){
	
}
library(int id,String bookname,String authorname,double price)
{
	this.id=id;
	this.bookname=bookname;
	this.authorname=authorname;
	this.price=price;
}


/**
 * @return the id
 */
public int getId() {
	return id;
}
/**
 * @param id the id to set
 */
public void setId(int id) {
	this.id = id;
}

/**
 * @return the bookname
 */
public String getBookname() {
	return bookname;
}
/**
 * @param bookname the bookname to set
 */
public void setBookname(String bookname) {
	this.bookname = bookname;
}
/**
 * @return the authorname
 */
public String getAuthorname() {
	return authorname;
}
/**
 * @param authorname the authorname to set
 */
public void setAuthorname(String authorname) {
	this.authorname = authorname;
}
/**
 * @return the price
 */
public double getPrice() {
	return price;
}
/**
 * @param price the price to set
 */
public void setPrice(double price) {
	this.price = price;
}
public String toString(){
	return"id "+id+ "\nbookname "+bookname+ "\nauthorname "+authorname+ "\nprice "+price;
	
}
}
