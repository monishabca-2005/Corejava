package day15;

public class UI {
	
  public static void main(String[] args) {
	  library lib=new library(100,"java","monisha",30000);
	  System.out.println(lib);
  }

}
